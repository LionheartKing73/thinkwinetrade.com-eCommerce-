<?php
// Text
$_['text_information']  = 'Information';
$_['text_service']      = 'The Community';
$_['text_extra']        = 'Extras';
$_['text_contact']      = 'Contact Us';
$_['text_return']       = 'Returns';
$_['text_sitemap']      = 'Site Map';
$_['text_manufacturer'] = 'Brands';
$_['text_voucher']      = 'Gift Vouchers';
$_['text_affiliate']    = 'Affiliates';
$_['text_special']      = 'Specials';
$_['text_account']      = 'My Account';
$_['text_order']        = 'Order History';
$_['text_wishlist']     = 'Wish List';
$_['text_newsletter']   = 'Newsletter';
$_['text_powered']      = 'Powered By <a href="http://www.opencart.com">OpenCart</a><br /> %s &copy; %s';
$_['text_community']  = 'The Community';
$_['text_pubsanbars']  = 'Pubs an Bars!';
$_['text_hotels']  = 'Hotels';
$_['text_boutiques']  = 'Boutiques & Merchants';
$_['text_catering']  = 'Catering and Company Events';
$_['text_rarestuffs']  = 'Rare Stuffs';
$_['text_tours']  = 'Tours';