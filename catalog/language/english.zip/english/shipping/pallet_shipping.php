<?php
// Text
$_['text_title']       = 'Pallet Shipping';
$_['text_description'] = 'Pallet Shipping Rate';
$_['text_shipping']  = 'Shipping Cost For %s Pallet(s)';