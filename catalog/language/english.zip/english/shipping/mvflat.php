<?php
// Text
$_['text_title']       = 'Multi Vendor / DropShipper Flat Rate';
$_['text_description'] = 'Flat Shipping Rate Per Item';
$_['text_weight'] 	   = 'Weight:'; 
?>