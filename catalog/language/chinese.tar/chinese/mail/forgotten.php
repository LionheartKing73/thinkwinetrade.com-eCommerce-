<?php
// Text
$_['text_subject']  = '%s - 会员新密码';
$_['text_greeting'] = '我们从 %s 收到您需要变更新的密码，建议您在使用新密码登陆后立即变更系统给与的密码，并妥善保存...';
$_['text_password'] = '您的新密码：';
