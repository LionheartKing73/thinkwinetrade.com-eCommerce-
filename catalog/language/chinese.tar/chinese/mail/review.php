<?php
// Text
$_['text_subject']	= '%s - 商品评论';
$_['text_waiting']	= '你有一个新产品的评论。';
$_['text_product']	= '商品： %s';
$_['text_reviewer']	= '评论者： %s';
$_['text_rating']	= '评级： %s';
$_['text_review']	= '评论文字：';
