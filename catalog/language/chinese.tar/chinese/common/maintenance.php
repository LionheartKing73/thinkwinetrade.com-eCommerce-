<?php
// Heading
$_['heading_title']     = '系统维护';

// Text
$_['text_maintenance']  = '系统维护';
$_['text_message']      = '<h1 style="text-align:center;">我们正在进行系统维护中。 <br/>本次维护将很快结束，请稍后访问。</h1>';
