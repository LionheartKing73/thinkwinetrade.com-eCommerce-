<?php
// Text
$_['text_items']             = '%s 个商品 - %s';
$_['text_empty']             = '您的购物车内没有商品！';
$_['text_cart']     = '查看购物车';
$_['text_checkout'] = '结账';
$_['text_recurring']  = '分期付款';

//pallet module
$_['text_pallet_worksheet'] = '我的托盘';
