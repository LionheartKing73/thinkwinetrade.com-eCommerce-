<?php
// Heading
$_['heading_title'] = '使用折扣券';

// Text
$_['text_success']  = '您已经成功使用折扣券！';

// Entry
$_['entry_coupon']  = '请输入您的折扣券：';

// Error
$_['error_coupon']  = '警告：优惠券是无效，过期或达到其使用限制！';
$_['error_empty']   = '警告：请输入优惠券代码！';