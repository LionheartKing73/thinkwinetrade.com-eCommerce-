<?php
// Heading
$_['heading_title'] = '使用奖励积分（可用%s）';

// Text
$_['text_success']  = '成功：您的积分优惠已应用！';

// Entry
$_['entry_reward']  = '奖励积分 (最多可用 %s)';

// Error
$_['error_reward']  = '警告：请输入奖励积分的数量！';
$_['error_points']  = '警告：您没有 %s 的积分奖励！';
$_['error_maximum'] = '警告：你可使用的最大积分数为%s！';
