<?php
// Text
$_['text_upload']    = '已经成功上传您的文件！';

// Error
$_['error_filename'] = '文件名必须大于3个字符，小于64个小符！';
$_['error_filetype'] = '无效文件类型！';
$_['error_upload']   = '上传错误！';
