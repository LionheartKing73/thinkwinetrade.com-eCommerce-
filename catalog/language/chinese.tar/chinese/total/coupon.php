<?php
// Heading 
$_['heading_title'] = '使用折扣券';

// Text
$_['text_coupon']   = '折扣券(%s)';
$_['text_success']  = '成功： 您已成功使用折扣券！';

// Entry
$_['entry_coupon']  = '请输入您的折扣券：';

// Error
$_['error_coupon']  = '警告： 折扣券已失效，或已过期，或已超过其使用次数！';
