<?php
$_['text_credit']   = '购物抵用金';
$_['text_order_id'] = '订单号： #%s';
