<?php
$_['text_handling'] = '手续费';
