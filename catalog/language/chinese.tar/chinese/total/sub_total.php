<?php
$_['text_sub_total'] = '商品总额';
