<?php
$_['text_klarna_fee'] = 'Klarna 收费';
