<?php
// Heading 
$_['heading_title'] = '使用礼品券';

// Text
$_['text_voucher']  = '礼品券(%s)';
$_['text_success']  = '成功： 您的礼品券已经成功使用！';

// Entry
$_['entry_voucher'] = '请输入您的礼品券代码：';

// Error
$_['error_voucher'] = '警告： 无效礼品券或此礼品券已经被使用！';
