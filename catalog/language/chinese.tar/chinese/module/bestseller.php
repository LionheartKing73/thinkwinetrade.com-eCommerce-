<?php
// Heading 
$_['heading_title']  = '热卖商品';

// Text
$_['text_reviews']     = '%s / 5 星！';
$_['text_tax']      = '税前：';


//pricing display
$_['text_bottle'] = '容量/瓶 75 cl'; $_['text_percases'] = '瓶/箱';
