<?php
// Heading 
$_['heading_title']    = '账户';

// Text
$_['text_register']    = '注册';
$_['text_login']       = '登录';
$_['text_logout']      = '退出账户';
$_['text_forgotten']   = '忘记密码';
$_['text_account']     = '我的账户';
$_['text_edit']        = '编辑账户';
$_['text_password']    = '更新密码';
$_['text_address']     = '地 址 薄';
$_['text_wishlist']    = '收藏列表';
$_['text_order']       = '历史订单';
$_['text_download']    = '下载商品';
$_['text_reward']      = '奖励积分';
$_['text_return']      = '商品退换';
$_['text_transaction'] = '资金余额';
$_['text_newsletter']  = '订阅资讯';
$_['text_recurring']     = '分期付款';
