<?php
// Heading 
$_['heading_title']  = 'Google 翻译';
?>