<?php
$_['heading_title'] = '欢迎访问 %s';
?>