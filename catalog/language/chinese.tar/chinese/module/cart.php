<?php
// Heading 
$_['heading_title'] = '购物车';

// Text
$_['text_items']    = '%s 项商品 - %s';
$_['text_empty']    = '您的购物车没有添加商品！';
$_['text_cart']     = '查看购物车';
$_['text_checkout'] = '结算';

$_['text_payment_profile'] = '付款资料';
?>