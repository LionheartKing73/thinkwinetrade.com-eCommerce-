<?php
// Text
$_['text_title']       = '托盘运输';
$_['text_description'] = '运输托盘的细节';
$_['text_shipping']  = '运输的价格为 %s 托盘';