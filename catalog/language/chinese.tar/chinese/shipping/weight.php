<?php
// Text
$_['text_title'] = '按重量计费';
$_['text_weight'] = '重量：'; 
