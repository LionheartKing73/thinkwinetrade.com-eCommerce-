<?php
//Text
$_['text_paid_amazon'] = '在亚马逊支付';

//Order totals
$_['text_total_shipping'] = '配送方式';
$_['text_total_shipping_tax'] = '配送税';
$_['text_total_giftwrap'] = '礼品包装';
$_['text_total_giftwrap_tax'] = '礼品包装税';
$_['text_total_sub'] = '小计';
$_['text_tax'] = '税';
$_['text_total'] = '总计';
