<?php
// Text
$_['text_total_shipping']		= '配送方式';
$_['text_total_discount']		= '折扣';
$_['text_total_tax']			= '税';
$_['text_total_sub']			= '小计';
$_['text_total']				= '总计';