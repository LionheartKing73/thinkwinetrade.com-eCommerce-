<?php
// Text
$_['text_error'] = '未找到信息页！';
