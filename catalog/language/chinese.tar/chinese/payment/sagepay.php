<?php
// Text
$_['text_title']       = '信用卡 / 借记卡 (SagePay)';
$_['text_description'] = '物品 %s 订单号： %s';
?>