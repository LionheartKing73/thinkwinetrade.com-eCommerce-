<?php
// Text
$_['text_title'] = '信用卡或借记卡';
$_['text_secure_connection'] = '正在创建安全连接...';

//Error
$_['error_connection'] = "无法连接到PayPal。请联系店的管理员寻求帮助，或选择其他付款方式。";
