<?php
// Text
$_['text_title'] = '信用卡或借记卡 (Payza)';
