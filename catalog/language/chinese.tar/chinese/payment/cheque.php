<?php
// Text
$_['text_title']       = '支票 / 汇票指令';
$_['text_instruction'] = '支票 / 汇票付款说明';
$_['text_payable']     = '款项汇至： ';
$_['text_address']     = '发送到： ';
$_['text_payment']     = '收到付款后我们将按照您的订单发货。';
