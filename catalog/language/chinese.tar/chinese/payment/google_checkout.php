<?php
// Entry
$_['text_title'] = '信用卡 / 借记卡 (Google Checkout)';

// Error
$_['error_shipping'] = '警告：配送方式必选！';
?>
