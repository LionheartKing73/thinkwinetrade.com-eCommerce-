<?php
// Text
$_['text_title']       = '银行转帐';
$_['text_instruction'] = '银行转帐指令:';
$_['text_description'] = '请将订单总额转账到以下银行账户。';
$_['text_payment']     = '收到付款后我们将按订单给您发货。';
