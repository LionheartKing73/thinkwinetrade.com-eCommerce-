<?php
// Text
$_['text_title'] 	= 'PayPal';
$_['text_reason'] 	= '原因';
$_['text_testmode']	= '警告：目前支付方式为沙盒模式（测试）。您的帐户将无法收款。';
$_['text_total']	= '货运，手续费，折扣和税费';
