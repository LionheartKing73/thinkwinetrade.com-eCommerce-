<?php
// Heading 
$_['heading_title'] = '退出账号';

// Text
$_['text_message']  = '<p>您已退出了您的账户。 可以安全离开电脑了。</p>';
$_['text_account']  = '账号';
$_['text_logout']   = '退出';
