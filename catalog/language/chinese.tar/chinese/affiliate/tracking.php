<?php
// Heading 
$_['heading_title']    = '联盟跟踪';

// Text
$_['text_account']     = '账户';
$_['text_description'] = '为了确保您能得到我们发送的付款，我们需要跟踪放置在URL跟踪代码链接给我们，您可以使用下面的工具来生成 %s 链接网站。';

// Entry
$_['entry_code']       = '您的跟踪代码';
$_['entry_generator']  = '跟踪链接生成';
$_['entry_link']       = '跟踪链接';

// Help
$_['help_generator']  = '键入您想链接产品的名称';
