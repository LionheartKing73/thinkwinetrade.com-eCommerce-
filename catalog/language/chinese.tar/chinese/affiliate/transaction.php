<?php
// Heading 
$_['heading_title']      = '资金余额';

// Column
$_['column_date_added']  = '资金余额日期';
$_['column_description'] = '说明';
$_['column_amount']      = '合计 (%s)';

// Text
$_['text_account']       = '账户';
$_['text_transaction']   = '我的资金余额';
$_['text_balance']       = '我的资金余额为：';
$_['text_empty']         = '您还没有任何资金余额记录！';
