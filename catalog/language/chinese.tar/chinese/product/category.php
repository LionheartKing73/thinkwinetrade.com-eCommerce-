<?php
// Text
$_['text_refine']       = '高级搜索';
$_['text_product']      = '商品';
$_['text_error']        = '分类不存在！';
$_['text_empty']        = '抱歉！ 此分类暂时没有相关商品。';
$_['text_quantity']     = '数量：';
$_['text_manufacturer'] = '品牌：';
$_['text_model']        = '商品型号：'; 
$_['text_points']       = '积分：'; 
$_['text_price']        = '价格：'; 
$_['text_tax']          = '税前：'; 
$_['text_compare']      = '对比(%s)'; 
$_['text_sort']         = '排序方式：';
$_['text_default']      = '默认';
$_['text_name_asc']     = '名称（A - Z）';
$_['text_name_desc']    = '名称（Z - A）';
$_['text_price_asc']    = '价格（低 &gt; 高）';
$_['text_price_desc']   = '价格（高 &gt; 低）';
$_['text_rating_asc']   = '最低评级'; 
$_['text_rating_desc']  = '最高评级';
$_['text_model_asc']    = '型号（A - Z）';
$_['text_model_desc']   = '型号（Z - A）';
$_['text_limit']        = '显示：';
$_['text_reviews']      = '基于 %s 评价。'; 
$_['text_display']      = '显示方式：';
$_['text_list']         = '列表';
$_['text_grid']         = '方格';

//pallet module
$_['text_triangle'] = '欢迎来到您的购物车，您可以建立您自己的托盘。每个托盘中做多容纳100箱。每个生产者不能少于20箱，您最多可以选择5个生产者在每个托盘中。';
$_['text_popup_title'] = '建立您的托盘';
$_['text_popup_qty'] = '请输入您所需要的箱数';
$_['button_addtopallet'] = '增加到我的托盘';
$_['text_popup_details'] = '当前托盘细节';
$_['text_popup_column_sellers'] = '生产者';
$_['text_popup_column_name'] = '产品';
$_['text_popup_column_qty'] = '数量';
$_['text_popup_column_total'] = '总计';
$_['text_pallet_worksheet'] = '我的托盘';

$_['text_bottle'] = '容量/瓶 75 cl'; $_['text_percases'] = '瓶/箱';