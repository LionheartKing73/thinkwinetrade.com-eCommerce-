<?php
// Text
$_['text_success']     = '成功：您的积分优惠已应用！';

// Error
$_['error_permission'] = '警告：您没有权限访问该 API!';
$_['error_reward']     = '警告：请输入奖励积分使用量！';
$_['error_points']     = '警告：您没有%s的积分奖励！';
$_['error_maximum']    = '警告：最大可使用积分为%s！';