<?php
// Text
$_['text_success'] = '成功：API会话启动成功！';

// Error
$_['error_login']  = '警告：不匹配的用户名或密码。';