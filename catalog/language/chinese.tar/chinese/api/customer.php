<?php
// Text
$_['text_success']       = '您已成功修改客户';

// Error
$_['error_permission']   = '警告：您没有权限访问该API!';
$_['error_firstname']    = '名字必须在1到32个字符之间！';
$_['error_lastname']     = '姓氏必须在1到32个字符之间！';
$_['error_email']        = '电子邮件地址无效！';
$_['error_telephone']    = '联系电话必须是3到32个字符之间！';
$_['error_custom_field'] = '%s 必选！';