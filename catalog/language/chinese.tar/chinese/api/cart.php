<?php
// Text
$_['text_success']     = '成功：您已经修改您的购物车！';

// Error
$_['error_permission'] = '警告：您没有权限访问该API!';
$_['error_stock']            = '商品标有 *** 表示数量不足或没有存货！';
$_['error_minimum']          = '%s 最小起订量是 %s！';	
$_['error_store']      = '该商品已不能在本店购买！';
$_['error_required']   = '%s 必选!';