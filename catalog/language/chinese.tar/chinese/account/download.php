<?php
// Heading 
$_['heading_title']   = '下载商品';

// Text
$_['text_account']    = '我的账户';
$_['text_downloads']  = '下载商品';
$_['text_empty']      = '您没有购买过可下载的商品！';
$_['text_order']      = '订单号：';
$_['text_date_added'] = '添加日期：';
// Column
$_['column_order_id']   = '订单号';
$_['column_name']       = '名字：';
$_['text_remaining']  = '备注：';
$_['column_size']       = '规格：';
$_['text_download']   = '下载';
$_['column_date_added'] = '添加日期';
