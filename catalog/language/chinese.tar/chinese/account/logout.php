<?php
// Heading 
$_['heading_title'] = '账号退出';

// Text
$_['text_message']  = '<p>您已成功退出 </p>';
$_['text_account']  = '账号';
$_['text_logout']   = '退出';
