<?php
// Heading
$_['heading_title']            = '我的购物车';
$_['heading_title_long']       = '欢迎来到购物页面, 您可以建立您的托盘,<br>但是您要注意，请遵守购买的条款。:<br>1.在每个托盘中最多容纳100箱<br>2.每个生产者不能少于20箱<br>3.您最多可以选择5个不同生产者在每个托盘中';

// Text
$_['text_success']             = '成功: 您可以增加<a href="%s">%s</a> 到您的<a href="%s">购物车</a>!';
$_['text_remove']              = '成功: 你更改了您的购物车';
$_['text_login']               = '注意:您必须 <a href="%s">登陆</a> 或者<a href="%s">建立账号</a> 查看价格';
$_['text_items']               = '%s 项目 - %s';
$_['text_points']              = '奖励积分: %s';
$_['text_next']                = '如果您继续，请点击';
$_['text_next_choice']         = 'Choose if you have a discount code or reward points you want to use or would like to estimate your delivery cost.';
$_['text_empty']               = '您的购物车是空的，开始您的购物!';
$_['text_day']                 = '每天';
$_['text_week']                = '每星期';
$_['text_semi_month']          = '半个月';
$_['text_month']               = '每月';
$_['text_year']                = '每年';
$_['text_trial']               = '%s 每个 %s %s 为 %s 然后付款 ';
$_['text_recurring']           = '%s 每个 %s %s';
$_['text_length']              = ' 为了 %s 付款';
$_['text_until_cancelled']     = '取消';
$_['text_recurring_item']      = '定期项目';
$_['text_payment_recurring']   = '付款资料';
$_['text_trial_description']   = '%s 每个 %d %s(s) 为了 %d 然后付款';
$_['text_payment_description'] = '%s 每个 %d %s(s) 为了 %d 付款';
$_['text_payment_cancel']      = '%s 每个 %d %s(s) 定期项目';

$_['text_vendor']              = '卖家 ';
$_['text_preorder']            = '查看购物车中您选中的产品';
$_['text_preorder_info']       = ' %s 先生或女士, 祝贺您! 您正在查看你的购物列表, 我们正在准备您的订单，并核查与我们的合作伙伴。整个过程将持续2天或者3天.如果您已经确认您选择,请点击继续或者更改您的选择!<br>您将在继续后进行付款.';
$_['text_preorder_total']      = '购物+运输总价';
$_['text_modify']              = '更改';
$_['text_validate']            = '继续';

$_['text_pallet_space']        = '您还有缺少 %s 在您的托盘上. 请继续!';
$_['text_pallet_valid']        = '这个托盘已满.';
$_['text_pallet_valid_locked'] = '您的托盘已经通过和保存.';
$_['text_worksheet_shipping']  = '运输成本 %s 托盘';
$_['text_worksheet_subtotal']  = '小计';
$_['text_worksheet_total']     = '总价';
$_['text_pallet_total']        = '托盘的总价';
$_['text_pallet_empty']        = '您的托盘是空的, 您可增加您的选择点击 <a href="%s">这里</a>';

$_['text_all_pallet_valid']    = '您购物车已满并生效 - ';
$_['text_all_pallet_valid_or'] = '或者';
$_['text_all_pallet_valid_modal']    = '您购物车已满并生效';

$_['button_delete_pallet']     = '移除这个托盘';
$_['button_create_pallet']     = '建立新的托盘';
$_['button_redo_book']         = '重新编辑全部托盘中产品清单';
$_['button_modify_book']       = '编辑';
$_['button_validate_book']     = '验证';
$_['button_proceed_checkout']  = '结算';
$_['button_create_pallet_modal']     = '建立新的托盘';
$_['button_proceed_checkout_modal']  = '结算';

// Column
$_['column_image']             = '图像';
$_['column_vendor']            = '卖家';
$_['column_vendor_limit']      = '最少箱数';
$_['column_name']              = '生产者姓名';
$_['column_model']             = 'SKU';
$_['column_quantity']          = '数量';
$_['column_bottles']           = '瓶数';
$_['column_price']             = '价格/箱';
$_['column_total']             = '总计';
$_['column_pallet_total']      = '您的托盘总价';

// Error
$_['error_stock']              = '带星标的产品 *** 无法提供您所需要的数量或断货!';
$_['error_minimum']            = '最小的量 %s 是 %s!';
$_['error_required']           = '%s 需要!';
$_['error_product']            = '警告:在您的购物车中没有产品!';
$_['error_recurring_required'] = 'Please select a payment recurring!';

$_['error_cases_limit']        = '卖家 %s - 您可以增加 %s 想从这位生产者.';
$_['error_vendors_limit']      = '您可以增加 %s 生产者到这个托盘中. 如果您想增加更多产品从生产者, 请增加新的托盘.';
$_['error_pallet_limit']       = '请注意\'您不能增加 %s 在这个托盘中.';
$_['error_container_limit']    = '您已经有最大数量 %s 在托盘中.';
$_['error_login_required']     = '您不能在 <a href="%s">登陆</a> 前购买!';
$_['error_pallets_locked']     = '您所有的托盘已经锁定. 进入您的 <a href="%s">购物车</a> 解锁或者继续购物.';
$_['error_pallet_locked']      = '您的托盘已经锁定. 如果您需要更改，请解锁您的托盘.';
$_['error_get_pallet']         = 'Failed to get the Pallet.';
$_['error_action_failed']      = '抱歉，您之前的操作中有错误.';
$_['error_vendor_triangle']    = '每个卖家 %s 最少的箱数 ';

$_['error_pallet_invalid_full']     = '托盘不能通过. 请查看托盘中的购物!';

?>