<?php
// Text
$_['text_subject']  = 'Vous venez de recevoir un chèque-cadeau provenant de %s';
$_['text_greeting'] = 'Félicitations, vous venez de recevoir un chèque-cadeau d\'une valeur de %s';
$_['text_from']     = 'Ce chèque-cadeau vous a été envoyé de la part de %s';
$_['text_message']  = 'Avec le message suivant';
$_['text_redeem']   = 'Pour échanger ce chèque-cadeau, notez bien le code de rachat qui est <b>%s</b>.Cliquez ensuite sur le lien ci-dessous et achetez le produit pour lequel vous souhaitez utiliser ce chèque-cadeau. Vous pourrez entrer le code du chèque-cadeau sur la page du panier avant de valider la commande.';
$_['text_footer']   = 'Veuillez répondre à cet e-mail si vous avez des questions ou besoin d\'informations supplémentaires.';
?>