<?php
// Text
$_['text_subject']       = '%s - Mise à jour du retour %s';
$_['text_return_id']     = 'Retour n°:';
$_['text_date_added']    = 'Date de retour:';
$_['text_return_status'] = 'Votre retour est passé dans l\'état:';
$_['text_comment']       = 'Les commentaires associés à votre retour sont:';
$_['text_footer']        = 'Veuillez répondre à cet e-mail si vous avez des questions ou besoin d\'informations supplémentaires.';
?>