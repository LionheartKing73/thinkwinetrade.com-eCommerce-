<?php
// Text
$_['text_subject']  = '%s - Demande de réinitialisation du mot de passe';
$_['text_greeting'] = 'Un nouveau mot de passe a été demandé pour l\'administration de %s.';
$_['text_change']   = 'Pour réinitialiser votre mot de passe, cliquez sur le lien ci-dessous:';
$_['text_ip']       = 'L\'adresse IP utilisée pour faire cette demande était: %s';
?>