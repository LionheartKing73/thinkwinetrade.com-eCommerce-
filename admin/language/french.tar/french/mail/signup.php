<?php
// Text
$_['text_dear']  	= 'Dear %s';
$_['text_subject1'] = '%s - You have been selected to participate in our vendor program';
$_['text_welcome1'] = 'Welcome and thank you for your interested at %s vendor program!';
$_['text_subject']  = '%s - Thank you for registering';
$_['text_url']  	= 'URL : ';
$_['text_info']     = '<b><u>Login Credential</u></b>';
$_['text_username'] = 'Username : ';
$_['text_password'] = 'Password : ';
$_['text_welcome']  = 'Welcome and thank you for registering at %s!';
$_['text_login']    = 'Your account has now been created and you can log in by using your login credential through following URL:';
$_['text_services'] = 'Upon logging in, you will be able to manage the account.';
$_['text_thanks']   = 'Thanks,';
?>