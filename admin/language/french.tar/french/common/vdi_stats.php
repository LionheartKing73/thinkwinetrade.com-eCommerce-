<?php
$_['text_complete_status']   = 'Commandes Complétées'; 
$_['text_processing_status'] = 'Commandes en Cours'; 
$_['text_other_status']      = 'Autres Statuts'; 