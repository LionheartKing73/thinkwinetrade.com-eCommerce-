<?php
// Text
$_['text_footer']   = 'Traduction française 20150401 <a href="http://www.moduloom.t15.org">Moduloom</a>.<br /><a href="http://www.opencart.com">OpenCart</a> &copy; 2009-' . date('Y') . ' Tous droits réservés.';
$_['text_version'] 	= 'Version %s';
?>