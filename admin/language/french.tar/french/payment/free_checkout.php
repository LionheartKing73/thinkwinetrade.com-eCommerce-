<?php
// Heading
$_['heading_title']      = 'Encaissement gratuit';

// Text
$_['text_payment']       = 'Paiement';
$_['text_success']       = 'Succès: Vous avez modifié les détails de paiement par encaissement gratuit !';
$_['text_edit']          = 'Modifier le paiement par encaissement gratuit';

// Entry
$_['entry_order_status'] = 'État de commande';
$_['entry_status']       = 'Statut';
$_['entry_sort_order']   = 'Classement';

// Error
$_['error_permission']   = 'Attention: Vous n\'avez pas les droits nécessaires pour modifier le paiement par encaissement gratuit !';
?>