<?php
// Heading
$_['heading_title']       = 'Affilié';

// Text
$_['text_module']         = 'Modules';
$_['text_success']        = 'Succès: Vous avez modifié le module Affilié !';
$_['text_edit']           = 'Modifier le module Affilié';

// Entry
$_['entry_status']        = 'Statut';

// Error
$_['error_permission']    = 'Attention: Vous n\'avez pas les droits nécessaires pour modifier le module Affilié !';
?>