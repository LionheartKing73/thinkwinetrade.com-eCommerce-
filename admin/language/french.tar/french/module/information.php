<?php
// Heading
$_['heading_title']       = 'Informations';

// Text
$_['text_module']         = 'Modules';
$_['text_success']        = 'Succès: Vous avez modifié le module Informations !';
$_['text_edit']           = 'Modifier le module Informations';

// Entry
$_['entry_status']        = 'Statut';

// Error
$_['error_permission']    = 'Attention: Vous n\'avez pas les droits nécessaires pour modifier le module Informations !';
?>