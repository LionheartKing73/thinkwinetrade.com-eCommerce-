<?php
// Heading
$_['heading_title']    = 'Bouton PayPal Express Checkout';

// Text
$_['text_module']      = 'Modules';
$_['text_success']     = 'Succès: Vous avez modifié le module Bouton PayPal Express Checkout !';
$_['text_edit']        = 'Modifier le module Bouton PayPal Express Checkout';

// Entry
$_['entry_status']     = 'Statut';

// Error
$_['error_permission'] = 'Attention: Vous n\'avez pas les droits nécessaires pour modifier le module Bouton PayPal Express Checkout !';
?>