<?php
// Heading
$_['heading_title']       = 'Boutique';

// Text
$_['text_module']         = 'Modules';
$_['text_success']        = 'Succès: Vous avez modifié le module Boutique !';
$_['text_edit']           = 'Modifier le module Boutique';

// Entry
$_['entry_admin']         = 'Administrateurs uniquement';
$_['entry_status']        = 'Statut';

// Error
$_['error_permission']    = 'Attention: Vous n\'avez pas les droits nécessaires pour modifier le module Boutique !';
?>