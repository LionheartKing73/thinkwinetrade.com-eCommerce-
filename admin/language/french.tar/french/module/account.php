<?php
// Heading
$_['heading_title']       = 'Compte';

// Text
$_['text_module']         = 'Modules';
$_['text_success']        = 'Succès: Vous avez modifié le module Compte !';
$_['text_edit']           = 'Modifier le module Compte';

// Entry
$_['entry_status']        = 'Statut';

// Error
$_['error_permission']    = 'Attention: Vous n\'avez pas les droits nécessaires pour modifier le module Compte !';
?>