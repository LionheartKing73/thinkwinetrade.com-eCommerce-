<?php
// Heading
$_['heading_title'] = 'Accès refusé !';

// Text
$_['text_permission'] = 'Vous n\'avez pas les droits nécessaires pour accèder à cette page. Veuillez en référer à votre administrateur système.';
?>
