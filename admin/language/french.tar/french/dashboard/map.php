<?php
// Heading
$_['heading_title'] = 'Mappemonde';

$_['text_order']    = 'Commandes';
$_['text_sale']     = 'Ventes';
?>