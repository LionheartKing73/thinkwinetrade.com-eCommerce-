<?php
// Heading
$_['heading_title'] = 'Personnes en ligne';

// Text
$_['text_view']     = 'Plus...';
?>