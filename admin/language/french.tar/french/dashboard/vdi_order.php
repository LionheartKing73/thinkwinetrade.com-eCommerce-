<?php
// Heading
$_['heading_title'] = 'Nombre de Commandes';

// Text
$_['text_view']     = 'Voir...';