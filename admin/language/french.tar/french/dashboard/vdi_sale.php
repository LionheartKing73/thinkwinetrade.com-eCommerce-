<?php
// Heading
$_['heading_title'] = 'Total des Ventes';

// Text
$_['text_view']     = 'Plus...';