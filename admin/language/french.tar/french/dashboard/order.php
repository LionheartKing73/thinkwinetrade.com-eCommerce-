<?php
// Heading
$_['heading_title'] = 'Nombre de Commande';

// Text
$_['text_view']     = 'Plus...';
?>