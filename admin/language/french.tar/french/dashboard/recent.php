<?php
// Heading
$_['heading_title']     = 'Dernières Commandes';

// Column
$_['column_order_id']   = 'Commande N°';
$_['column_customer']   = 'Client';
$_['column_status']     = 'Statut';
$_['column_total']      = 'Total';
$_['column_date_added'] = 'Date Création';
$_['column_action']     = 'Action';
?>