<?php
// Heading
$_['heading_title']    = 'Rapport sur les Bons de Réduction';

// Text
$_['text_list']        = 'Liste des bons de réduction';

// Column
$_['column_name']      = 'Nom du bon de réduction';
$_['column_code']      = 'Code';
$_['column_orders']    = 'Commandes';
$_['column_total']     = 'Total';
$_['column_action']    = 'Action';

// Entry
$_['entry_date_start'] = 'Date de début';
$_['entry_date_end']   = 'Date de fin';
?>