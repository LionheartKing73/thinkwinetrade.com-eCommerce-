<?php
// Heading
$_['heading_title']    = 'Rapport Produits Consultés';

// Text
$_['text_list']        = 'Liste de vos Produits';
$_['text_success']     = 'Vous avez réinitialisé les rapports';

// Column
$_['column_name']      = 'Nom du Produit';
$_['column_model']     = 'Modèle';
$_['column_viewed']    = 'Nombre de Vue';
$_['column_percent']   = 'Pourcentage';

// Error
$_['error_permission'] = 'Warning: You do not have permission to reset product viewed report!';