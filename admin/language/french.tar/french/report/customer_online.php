<?php
// Heading
$_['heading_title']     = 'Rapport sur les Clients en Ligne';

// Text
$_['text_list']         = 'Liste des clients en ligne';
$_['text_guest']        = 'Invité';

// Column
$_['column_ip']         = 'IP';
$_['column_customer']   = 'Client';
$_['column_url']        = 'Dernière page visitée';
$_['column_referer']    = 'Parrain';
$_['column_date_added'] = 'Dernier Clic';
$_['column_action']     = 'Action';

// Entry
$_['entry_ip']          = 'IP';
$_['entry_customer']    = 'Customer';
?>