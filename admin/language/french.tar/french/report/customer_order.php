<?php
// Heading
$_['heading_title']         = 'Rapport sur les Commandes Clients';

// Text
$_['text_list']             = 'Liste des commandes clients';
$_['text_all_status']       = 'Tous les états';

// Column
$_['column_customer']       = 'Nom du client';
$_['column_email']          = 'E-mail';
$_['column_customer_group'] = 'Groupe du client';
$_['column_status']         = 'Statut';
$_['column_orders']         = 'Nb de commandes';
$_['column_products']       = 'Nb de produits';
$_['column_total']          = 'Total';
$_['column_action']         = 'Action';

// Entry
$_['entry_date_start']      = 'Date de début';
$_['entry_date_end']        = 'Date de fin';
$_['entry_status']          = 'État de commande';
?>