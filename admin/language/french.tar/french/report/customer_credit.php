<?php
// Heading
$_['heading_title']         = 'Rapport sur les Crédits Clients';

// Column
$_['text_list']             = 'Liste des crédits clients';
$_['column_customer']       = 'Nom Client';
$_['column_email']          = 'E-mail';
$_['column_customer_group'] = 'Groupe du Client';
$_['column_status']         = 'Statut';
$_['column_total']          = 'Total';
$_['column_action']         = 'Action';

// Entry
$_['entry_date_start']      = 'Date de début';
$_['entry_date_end']        = 'Date de fin';
?>