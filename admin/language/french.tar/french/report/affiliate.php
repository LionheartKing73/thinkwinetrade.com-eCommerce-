<?php
// Heading
$_['heading_title']     = 'Rapport sur les Commissions d\'Affiliés';

// Text
$_['text_list']         = 'Liste des commissions d\'affiliés';

// Column
$_['column_affiliate']  = 'Nom Affilié';
$_['column_email']      = 'E-mail';
$_['column_status']     = 'Statut';
$_['column_commission'] = 'Commission';
$_['column_orders']     = 'Nb de Commandes';
$_['column_total']      = 'Total';
$_['column_action']     = 'Action';

// Entry
$_['entry_date_start']  = 'Date de début';
$_['entry_date_end']    = 'Date de fin';
?>