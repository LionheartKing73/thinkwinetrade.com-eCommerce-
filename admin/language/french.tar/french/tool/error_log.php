<?php
// Heading
$_['heading_title']    = 'Journal des Erreurs';

// Text
$_['text_success']	   = 'Succès: Vous avez vidé votre journal des erreurs !';
$_['text_list']        = 'Liste des erreurs';

// Error
$_['error_warning']	   = 'Attention: Votre fichier journal des erreurs %s est %s !';
$_['error_permission'] = 'Attention: Vous n\'avez pas les droits nécessaires pour vider votre journal des erreurs !';
?>