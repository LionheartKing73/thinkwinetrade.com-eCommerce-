<?php
// Headings
$_['heading_title']         = 'Usage';
$_['text_openbay']          = 'OpenBay Pro';
$_['text_ebay']             = 'eBay';

// Text
$_['text_usage']            = 'Utilisation de votre compte';

// Errors
$_['error_ajax_load']       = 'Désolé, impossible d\'obtenir une réponse. Essayez plus tard.';
?>