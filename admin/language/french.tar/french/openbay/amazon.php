<?php
// Heading
$_['heading_title']               = 'Amazon EU';
$_['text_openbay']                = 'OpenBay Pro';
$_['text_dashboard']              = 'Tableau de bord Amazon EU';

// Text
$_['text_heading_settings']       = 'Paramètres';
$_['text_heading_account']        = 'Changer de plan';
$_['text_heading_links']          = 'Liens d\'objet';
$_['text_heading_register']       = 'Inscription';
$_['text_heading_bulk_listing']   = 'Annonces en masse';
$_['text_heading_stock_updates']  = 'Mises à jour du stock';
$_['text_heading_saved_listings'] = 'Annonces enregistrées';
$_['text_heading_bulk_linking']   = 'Liens en masse';
?>