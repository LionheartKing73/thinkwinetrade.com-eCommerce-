<?php
// Heading
$_['heading_title']    = 'Chèques-Cadeaux';

// Text
$_['text_total']       = 'Totaux de commande';
$_['text_success']     = 'Succès: Vous avez modifié le total des chèques-cadeaux !';
$_['text_edit']        = 'Modifier le total des chèques-cadeaux';

// Entry
$_['entry_status']     = 'Statut';
$_['entry_sort_order'] = 'Classement';

// Error
$_['error_permission'] = 'Attention: Vous n\'avez pas les droits nécessaires pour modifier le total des chèques-cadeaux !';
?>