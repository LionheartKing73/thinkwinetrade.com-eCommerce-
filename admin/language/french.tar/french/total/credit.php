<?php
// Heading
$_['heading_title']    = 'Crédit de la boutique';

// Text
$_['text_total']       = 'Totaux de Commande';
$_['text_success']     = 'Succès: Vous avez modifié le total du crédit de la boutique !';
$_['text_edit']        = 'Modifier le total du crédit de la boutique';

// Entry
$_['entry_status']     = 'Statut';
$_['entry_sort_order'] = 'Classement';

// Error
$_['error_permission'] = 'Attention: Vous n\'avez pas les droits nécessaires pour modifier le total du crédit de la boutique!';
?>