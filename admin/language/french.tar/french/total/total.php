<?php
// Heading
$_['heading_title']    = 'Total Général';

// Text
$_['text_total']       = 'Totaux de commande';
$_['text_success']     = 'Succès: Vous avez modifié le total “Total général” !';
$_['text_edit']        = 'Modifier le total “Total général”';

// Entry
$_['entry_status']     = 'Statut';
$_['entry_sort_order'] = 'Classement';

// Error
$_['error_permission'] = 'Attention: Vous n\'avez pas les droits nécessaires pour modifier le total “Total général” !';
?>