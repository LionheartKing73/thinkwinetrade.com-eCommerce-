<?php
$_['lang_btn_status']           = '改变订单状态';
$_['lang_order_channel']        = '订单来源';
$_['lang_confirmed']            = '个已标记订单更新为';
$_['lang_no_orders']            = '未选择要更新的订单';
$_['lang_confirm_title']        = '订单状态批量更新预览';
$_['lang_confirm_change_text']  = '将订单状态改变为';
$_['lang_column_addtional']     = '附加信息';
$_['lang_column_comments']      = '备注';
$_['lang_column_notify']        = '通知';
$_['lang_carrier']              = '货运方式';
$_['lang_tracking']             = '跟踪';
$_['lang_other']                = '其它';
$_['lang_refund_reason']        = '退换原因';
$_['lang_refund_message']       = '退换信息';
$_['lang_update']               = '确认更新';
$_['lang_cancel']               = '取消';
$_['lang_e_ajax_1']             = '订单缺少退款信息！';
$_['lang_e_ajax_2']             = '订单缺少跟踪信息！';
$_['lang_e_ajax_3']             = 'Amazon订单缺少货运信息！';
$_['lang_title_order_update']   = '批量订单更新';
?>
