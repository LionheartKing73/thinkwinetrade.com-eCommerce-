<?php
// Heading
$_['heading_title']     = '扩展配制';

// Text
$_['text_success']      = '成功：您已修改的修改扩展配制！';
$_['text_refresh']      = '当您启用/禁用或删除扩展配制模块，你需要单击刷新按钮来重建你修改缓存的修改！';
$_['text_list']         = '扩展配制清单';

// Column
$_['column_name']       = '扩展配制名称';
$_['column_author']     = '作者';
$_['column_version']    = '版本';
$_['column_status']     = '状态';
$_['column_date_added'] = '添加日期';
$_['column_action']     = '管理';

// Error
$_['error_permission']  = '警告：您没有权限修改扩展配制模块！';