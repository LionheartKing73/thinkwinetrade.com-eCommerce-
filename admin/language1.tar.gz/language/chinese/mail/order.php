<?php
// Text
$_['text_subject']      = '%s - 订单更新通知 （订单号： %s）';
$_['text_order']        = '订单号：';
$_['text_date_added']   = '日期排序：';
$_['text_order_status'] = '您的订单已更新为以下状态：';
$_['text_comment']      = '您的订单附言：';
$_['text_link']         = '要查看您的订单，请点击以下链接：';
$_['text_footer']       = '如果您有任何疑问，请直接回复此邮件。';
?>