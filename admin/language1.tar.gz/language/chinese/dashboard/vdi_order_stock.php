<?php
$_['text_low_stock_product'] = '<i class="fa fa-exclamation-triangle" style="color:red"></i> <a href="product_id=%s">%s</a> Attention! le stock pour ce produit est très bas <span class="label label-danger">%s</span> Le produit est désactivé mais sera remis en ligne dès que le stock sera supérieur à 10 cartons.';
?>