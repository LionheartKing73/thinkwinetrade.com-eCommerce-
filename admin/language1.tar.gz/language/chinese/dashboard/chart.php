<?php
// Heading
$_['heading_title'] = '销售分析';

// Text
$_['text_order']    = '订单数';
$_['text_customer'] = '客户数';
$_['text_day']      = '今天';
$_['text_week']     = '本周';
$_['text_month']    = '本月';
$_['text_year']     = '今年';