<?php
$_['text_noactions'] = '<br>
Nous vous remercions pour votre collaboration rapide. Cette commande est terminée, aucune action est nécessaire à ce stade du traitement, le paiement vous sera versé des reception des colis à notre entrepot et la validation de tous les documents.';
?>