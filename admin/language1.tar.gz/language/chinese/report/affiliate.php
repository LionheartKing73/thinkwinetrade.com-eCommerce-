<?php
// Heading
$_['heading_title']     = '联盟会员佣金统计';

// Text
$_['text_list']         = '联盟会员佣金清单';

// Column
$_['column_affiliate']  = '联盟会员名称';
$_['column_email']      = 'E-Mail';
$_['column_status']     = '状态';
$_['column_commission'] = '佣金';
$_['column_orders']     = '订单数量';
$_['column_total']      = '佣金总计';
$_['column_action']     = '管理';

// Entry
$_['entry_date_start']  = '开始日期：';
$_['entry_date_end']    = '结束日期：';
