<?php
// Heading
$_['heading_title']     = '客户在线报告';

// Text 
$_['text_list']         = '客户在线清单';
$_['text_guest']        = '游客';
 
// Column
$_['column_ip']         = 'IP地址';
$_['column_customer']   = '客户名';
$_['column_url']        = '最近访问的页面';
$_['column_referer']    = '引用页';
$_['column_date_added'] = '最近访问时间';
$_['column_action']     = '管 理';

// Entry
$_['entry_ip']          = 'IP';
$_['entry_customer']    = '客户';