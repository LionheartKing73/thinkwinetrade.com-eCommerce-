<?php
$_['text_need_approval'] = 'Votre compte est en cours de validation. Il sera validé sous 48H. Cependant vous pouvez déjà commencer a créer votre catalogue produits en ajoutant vos références! <br> <br>
L\'équipe TWT,';
$_['text_switch_language'] = 'Switch language';
?>