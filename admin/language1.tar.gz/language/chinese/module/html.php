<?php
// Heading
$_['heading_title']     = 'HTML内容';

// Text
$_['text_module']       = '模块';
$_['text_success']      = '成功：您已修改HTML内容模块！';
$_['text_edit']         = '编辑HTML内容模块';

// Entry
$_['entry_heading']     = '标题';
$_['entry_description'] = '内容';
$_['entry_status']      = '状态';

// Error
$_['error_permission']  = '警告：您没有权限修改HTML内容模块！';
