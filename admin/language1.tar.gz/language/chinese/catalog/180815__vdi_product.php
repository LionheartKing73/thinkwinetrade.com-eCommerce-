<?php
$_['heading_title'] = '产品';
$_['text_success'] = '成功：你已经修改了产品';
$_['text_list'] = '产品列表';
$_['text_add'] = '添加产品';
$_['text_edit'] = '编辑产品';
?>