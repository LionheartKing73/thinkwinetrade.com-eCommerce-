<?php
$_['warning_add_profile_image'] = '1ère ETAPE </br> Veuillez insérer la photo de la personne qui gère ce compte au bas de la page Détails de Votre Compte > Général > Votre Photo.';
?>