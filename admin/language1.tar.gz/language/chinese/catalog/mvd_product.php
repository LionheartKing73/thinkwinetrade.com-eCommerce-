<?php
$_['entry_pf'] = 'Packaging Format';
$_['entry_sp_price'] = 'TWT Price/Bottle';
$_['entry_price'] = 'TWT Price/Case';
$_['entry_fob_price'] = 'Fob Price/Bottle';
?>