<?php
// Text
$_['text_subject']  = '%s - 密碼重置請求';
$_['text_greeting'] = '一個新的管理員密碼%s.';
$_['text_change']   = '要重設密碼點擊以下鏈接：';
$_['text_ip']       = 'IP的使用需要這個請求： %s';