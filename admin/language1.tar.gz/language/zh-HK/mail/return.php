<?php
// Text
$_['text_subject']       = '%s - 退貨  %s 更新';
$_['text_return_id']     = '退貨 ID：';
$_['text_date_added']    = '退貨的日期：';
$_['text_return_status'] = '您的退貨已更新到以下狀態：';
$_['text_comment']       = '您退貨的意見：';
$_['text_footer']        = '如果您有任何問題請回復這個電子郵件。';