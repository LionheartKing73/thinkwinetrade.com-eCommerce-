<?php
// Heading
$_['heading_title']					= '뵵���ﮧ;

// Text
$_['text_payment']					= '֧趷튽';
$_['text_success']					= '㉹棺ĺґɹ搞脻嵽趿謹᧻
$_['text_edit']             = 'ᠼ���彸濮Ťփ';

// Entry
$_['entry_total']				   	= 'ל殧;
$_['entry_order_status']		= '橵嗴̬';
$_['entry_geo_zone']	      = 'ǸӲȺש';
$_['entry_status']		      = '״̬';
$_['entry_sort_order']	    = 'Ņ';

// Help
$_['help_total']		         = '橵嵄���˗ܶ䯵���ʽֵ㬴˖縶罊���롉ꐧ㡧;

// Error
$_['error_permission']				= '棺ĺuӐȨϞ脻嵽趿փ㡧;