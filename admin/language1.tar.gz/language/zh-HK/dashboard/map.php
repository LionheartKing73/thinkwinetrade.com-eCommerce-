<?php
// Heading
$_['heading_title'] = '整體概要';

$_['text_order']    = '訂單';
$_['text_sale']     = '銷售';