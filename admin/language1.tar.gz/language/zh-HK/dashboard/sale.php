<?php
// Heading
$_['heading_title'] = '銷售總額';

// Text
$_['text_view']     = '顯示詳細...';