<?php
// Heading
$_['heading_title'] = '在線客戶';

// Text
$_['text_view']     = '顯示詳細...';
