<?php
// Heading
$_['heading_title'] = '總訂單數';

// Text
$_['text_view']     = '顯示詳細...';