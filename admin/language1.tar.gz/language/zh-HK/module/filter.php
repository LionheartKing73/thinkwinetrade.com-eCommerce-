<?php
// Heading
$_['heading_title']    = '篩選器';

// Text
$_['text_module']         = '篩選器模塊';
$_['text_success']        = '成功：: 您已經修改了篩選器模塊！';
$_['text_edit']        = '編輯篩選器模塊';

// Entry
$_['entry_status']     = '狀態';

// Error
$_['error_permission']    = '警告：您沒有修改這個模塊的權限！';