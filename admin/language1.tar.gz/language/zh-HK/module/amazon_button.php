<?php
// Heading
$_['heading_title']    = '亞馬遜支付按鈕';

$_['text_module']      = '模塊管理';
$_['text_success']     = '已成功修改亞馬遜支付按鈕(亞馬遜支付)模組設置';
$_['text_edit']        = '編輯亞馬遜支付模塊';
$_['text_left']        = '左列';
$_['text_right']       = '右列';
$_['text_center']      = '中部';

// Entry
$_['entry_name']       = '模塊名稱';
$_['entry_align']      = '對齊';
$_['entry_status']     = '狀態';

// Error
$_['error_permission']     = '警告：您沒有權限修亞馬遜支付模塊！';
$_['error_name']       = '模塊名稱必須是 3 至 64 個字符之間！';