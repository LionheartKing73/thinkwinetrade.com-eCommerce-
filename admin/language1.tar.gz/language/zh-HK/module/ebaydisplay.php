<?php
// Heading
$_['heading_title']     = 'eBay չʾ';

// Text
$_['text_module']         = 'ģ啕܀���
$_['text_success']        = '㉹榮꒑脫謹᧻
$_['text_list']         	= '⼾ց���
$_['text_start_newest'] 	= 'ϔʾ׮Ђ僣;
$_['text_start_random'] 	= '˦뺏Ԋ

// Entry
$_['entry_limit']       = 'ʽϞֆ';
$_['entry_image']       = 'ͼƬ䳐ᠨW x H)';
$_['entry_username']    = 'eBay Ӄ맃맻
$_['entry_keywords']    = 'ˑ˷阼촊';
$_['entry_description'] = 'ༀ苵÷ˑ˷';
$_['entry_site']   		  = 'eBay ͸媧;

// Error
$_['error_permission']    = '榮ꃻӐȨϞᤸ챾ģ謹᧻
$_['error_image']         = 'ͼƬﭶȦamp; 蟶ȱ،';