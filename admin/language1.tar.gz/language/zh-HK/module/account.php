<?php
// Heading
$_['heading_title']    = '賬戶';

$_['text_module']      = '模塊管理';
$_['text_success']        = '成功：您已修改賬戶模塊！';
$_['text_edit']        = '編輯賬戶模塊';

// Entry
$_['entry_status']     = '狀態';

// Error
$_['error_permission']    = '警告：您沒有權限修改賬戶模塊！';