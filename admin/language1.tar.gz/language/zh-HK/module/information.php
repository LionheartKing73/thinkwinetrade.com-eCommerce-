<?php
// Heading
$_['heading_title']    = '網站信息';

// Text
$_['text_module']      = '模塊管理';
$_['text_success']        = '成功： 您已修改信息模塊！';
$_['text_edit']        = '編輯信息模塊';

// Entry
$_['entry_status']     = '狀態';

// Error
$_['error_permission']    = '警告： 您沒有權限變更信息模塊！';