<?php
// Heading
$_['heading_title']     = 'HTML內容';

// Text
$_['text_module']       = 'HTML內容模塊';
$_['text_success']      = '成功：您已修改HTML內容模塊！';
$_['text_edit']         = '編輯HTML內容模塊';

// Entry
$_['entry_name']        = '模塊名稱';
$_['entry_title']       = '標題';
$_['entry_description'] = '描述';
$_['entry_status']      = '狀態';

// Error
$_['error_permission']  = '警告：您沒有權限修改HTML內容模塊！';
$_['error_name']        = '模塊名稱必須是 3 至 64 個字符之間！';
