<?php
// Heading
$_['heading_title']       = '加盟會員';

$_['text_module']         = '模塊管理';
$_['text_success']        = '成功：您已修改加盟會員模塊！';
$_['text_edit']        = '編輯加盟會員模塊';

// Entry
$_['entry_status']        = '狀態：';

// Error
$_['error_permission']    = '警告：您沒有權限修改加盟會員模塊！';