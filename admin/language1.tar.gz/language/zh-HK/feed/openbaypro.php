<?php
// Heading
$_['heading_title']	  = '大市場平台';

// Text
$_['text_module']    = '模塊';
$_['text_installed'] = '大市場平台模塊安裝完畢。它可以在擴展功能 -> 大市場平台中找到';