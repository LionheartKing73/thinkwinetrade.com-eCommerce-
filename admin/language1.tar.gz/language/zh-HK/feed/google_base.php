<?php
// Heading
$_['heading_title']    = '谷歌擴展';

// Text
$_['text_feed']        = '插件擴展';
$_['text_success']     = '成功： 您已變更谷歌擴展！';
$_['text_list']        = '佈局列表';
$_['text_edit']        = '編輯谷歌擴展';

// Entry
$_['entry_status']     = '狀態：';
$_['entry_data_feed']  = '資料數據網址：';

// Error
$_['error_permission'] = '警告： 您沒有權限修改谷歌擴展！';