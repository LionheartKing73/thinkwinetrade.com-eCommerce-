<?php
// Heading
$_['heading_title']    = '到商店自提';

// Text
$_['text_shipping']    = '配送管理';
$_['text_success']     = '成功您已修改到商店自提！';
$_['text_edit']        = '編輯到店自提配送';

// Entry
$_['entry_geo_zone']   = '區域群組';
$_['entry_status']     = '狀態';
$_['entry_sort_order'] = '排序';

// Error
$_['error_permission'] = '警告您沒有權限修改到商店自提！';