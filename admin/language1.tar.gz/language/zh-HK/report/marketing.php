<?php
// Heading
$_['heading_title']    = '市場營銷報告';

// Text
$_['text_list']         = '市場報告列表';
$_['text_all_status']   = '所有狀態';

// Column
$_['column_campaign']  = '活動名稱';
$_['column_code']      = '代碼';
$_['column_clicks']    = '瀏覽次數';
$_['column_orders']    = '訂單號';
$_['column_total']     = '合計';

// Entry
$_['entry_date_start'] = '開始日期';
$_['entry_date_end']   = '結束日期';
$_['entry_status']     = '訂單狀態';