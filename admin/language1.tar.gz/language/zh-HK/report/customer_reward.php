<?php
// Heading
$_['heading_title']         = '客戶獎勵積分統計';

// Text
$_['text_list']             = '客戶獎勵積分列表';

// Column
$_['column_customer']       = '客戶名稱';
$_['column_email']          = 'E-Mail';
$_['column_customer_group'] = '用戶組';
$_['column_status']         = '狀態';
$_['column_points']         = '獎勵積分';
$_['column_orders']         = '訂單號';
$_['column_total']          = '金額總計';
$_['column_action']         = '管理';

// Entry
$_['entry_date_start']      = '開始日期';
$_['entry_date_end']        = '結束日期';