<?php
// Heading
$_['heading_title']  = '商品瀏覽報表';

// Text
$_['text_list']        = '商品瀏覽列表';
$_['text_success']   = '成功： 您已重設商品瀏覽報表！';

// Column
$_['column_name']    = '商品名稱';
$_['column_model']   = '商品型號';
$_['column_viewed']  = '瀏覽次數';
$_['column_percent'] = '按百分比';

// Error
$_['error_permission'] = '警告: 您沒有權限設置瀏覽報表！';