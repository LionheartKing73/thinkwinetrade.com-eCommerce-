<?php
// Heading
$_['heading_title']   = '權限不足！';

// Text
$_['text_permission'] = '您沒有權限訪問此頁面，請聯繫系統管理員。';
?>