<?php
// Heading
$_['heading_title']      = '配送管理';

// Text
$_['text_success']      = '成功：您已經修改了配送方式！';
$_['text_list']         = '配送列表';

// Column
$_['column_name']        = '配送方式';
$_['column_status']      = '狀態';
$_['column_sort_order']  = '排序';
$_['column_action']      = '管理';

// Error
$_['error_permission']   = '警告： 您沒有權限修改配送管理！';