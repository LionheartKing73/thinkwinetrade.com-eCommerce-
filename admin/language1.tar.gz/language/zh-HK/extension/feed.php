<?php
// Heading
$_['heading_title']      = '插件擴展';

// Text
$_['text_success']     = '成功: 您已經修改了擴展！';
$_['text_list']        = '擴展列表';

// Column
$_['column_name']        = '插件名稱';
$_['column_status']      = '狀態';
$_['column_action']      = '管理';

// Error
$_['error_permission']   = '警告： 您沒有權限修改插件擴展！';