<?php
$_['text_complete_status']   = '訂單已經完成';
$_['text_processing_status'] = '訂單待處理';
$_['text_other_status']      = '其它狀態';