<?php

// Heading
$_['heading_title'] = 'PayPal快速结帐(PayPal Express Checkout)按钮';

// Text
$_['text_module']          = '模块管理';
$_['text_success']        = '已成功修改PayPal快速结帐(PayPal Express Checkout)按钮模组设置';
$_['text_content_top']     = '内容的上面';
$_['text_content_bottom']  = '内容的底部';
$_['text_column_left']     = '左列显示';
$_['text_column_right']    = '右列显示';

$_['entry_layout']         = '布局：';
$_['entry_position']       = '显示位置：';
$_['entry_status']         = '状态：';
$_['entry_sort_order']     = '排序：';

$_['error_permission']     = '警告：您没有权限修改PayPal Express模块！';
?>