<?php
$_['column_subtotal'] = 'Sous-Total HT';
$_['text_vat'] = 'Dont TVA (20%)';
?>