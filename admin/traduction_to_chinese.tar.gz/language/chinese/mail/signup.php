<?php
$_['text_services'] = 'Vous pouvez modifier vos information après chaque connexion ';
?>