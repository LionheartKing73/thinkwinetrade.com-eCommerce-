<?php
$_['column_fob_price'] = 'Fob Price/Bottle';
$_['column_sp_price'] = 'TWT Price/Bottle';
$_['entry_sp_price'] = 'TWT Price/Bottle';
$_['entry_price'] = 'Special Price/Bottle';
?>