<?php
// Heading
$_['heading_title']    = '小计';

// Text
$_['text_total']       = '订单总计';
$_['text_success']     = '成功： 您已成功修改商品小计！';
$_['text_edit']        = '编辑小计';

// Entry
$_['entry_status']     = '状态：';
$_['entry_sort_order'] = '排序：';

// Error
$_['error_permission'] = '警告： 您没有变更小计的权限！';
