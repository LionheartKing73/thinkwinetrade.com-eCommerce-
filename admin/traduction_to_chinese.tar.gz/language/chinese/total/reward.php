<?php
// Heading
$_['heading_title']    = '奖励积分';

// Text
$_['text_total']       = '订单金额';
$_['text_success']     = '成功： 您已成功修改积分！';
$_['text_edit']        = '编辑奖励积分';

// Entry
$_['entry_status']     = '状态：';
$_['entry_sort_order'] = '排序：';

// Error
$_['error_permission'] = '警告： 您没有变更积分的权限！';
