<?php
// Heading
$_['heading_title'] = '客户在线';

// Text
$_['text_view']     = '显示详细...';
