<?php
// Heading
$_['heading_title']	  = 'OpenBay Pro';

// Text
$_['text_module']    = '模块';
$_['text_installed'] = 'OpenBay Pro 模块安装完毕。它可以在扩展功能 -> OpenBay Pro中找到';