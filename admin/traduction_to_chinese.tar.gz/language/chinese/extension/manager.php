<?php
// Heading 
$_['heading_title']    = '插件管理';

// Text
$_['text_success']     = '成功：你已经安装了你的插件！';

// Error
$_['error_permission'] = '警告：您没有权限修改这个插件！';
$_['error_upload']     = '请先上传！';
$_['error_filetype']   = '不支持的文件类型！';
?>