<?php
// Heading
$_['heading_title']     = 'Paiements';

// Text
$_['text_success']      = 'Succès: Vous avez modifié les paiements !';
$_['text_list']         = 'Liste des paiements';

// Column
$_['column_name']       = 'Mode de Paiement';
$_['column_status']     = 'Statut';
$_['column_sort_order'] = 'Classement';
$_['column_action']     = 'Action';

// Error
$_['error_permission']  = 'Attention: Vous n\'avez pas les droits nécessaires pour modifier les paiements !';
?>