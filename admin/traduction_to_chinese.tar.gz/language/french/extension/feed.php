<?php
// Heading
$_['heading_title']    = 'Flux descriptifs de Produits';

// Text
$_['text_success']     = 'Succès: Vous avez modifié les flux descriptifs !';
$_['text_list']        = 'Liste des flux descriptifs';

// Column
$_['column_name']      = 'Nom du Flux de Produit';
$_['column_status']    = 'Statut';
$_['column_action']    = 'Action';

// Error
$_['error_permission'] = 'Attention: Vous n\'avez pas les droits nécessaires pour modifier les flux descriptifs !';
?>