<?php
// Heading
$_['heading_title']     = 'Totaux de Commande';

// Text
$_['text_success']      = 'Succès: Vous avez modifié les totaux !';
$_['text_list']         = 'Liste des totaux de commande';

// Column
$_['column_name']       = 'Nom du Total de Commande';
$_['column_status']     = 'Statut';
$_['column_sort_order'] = 'Classement';
$_['column_action']     = 'Action';

// Error
$_['error_permission']  = 'Attention: vous n\'avez pas la permission de modifier les totaux !';
?>