<?php
// Heading
$_['heading_title']    = 'Enlèvement sur place';

// Text
$_['text_shipping']    = 'Livraison';
$_['text_success']     = 'Succès: Vous avez modifié l\'enlèvement sur place !';
$_['text_edit']        = 'Modifier l\'enlèvement sur place';

// Entry
$_['entry_geo_zone']   = 'Zone géographique';
$_['entry_status']     = 'Statut';
$_['entry_sort_order'] = 'Classement';

// Error
$_['error_permission'] = 'Attention: Vous n\'avez pas les droits nécessaires pour modifier l\'enlèvement sur place !';
?>