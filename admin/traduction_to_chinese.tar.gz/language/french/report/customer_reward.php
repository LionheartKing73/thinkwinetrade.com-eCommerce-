<?php
// Heading
$_['heading_title']         = 'Rapport sur les Points de Fidélité Clients';

// Text
$_['text_list']             = 'Liste des points de fidélité clients';

// Column
$_['column_customer']       = 'Nom du client';
$_['column_email']          = 'E-mail';
$_['column_customer_group'] = 'Groupe du client';
$_['column_status']         = 'Statut';
$_['column_points']         = 'Points de fidélité';
$_['column_orders']         = 'Nombre de commandes';
$_['column_total']          = 'Total';
$_['column_action']         = 'Action';

// Entry
$_['entry_date_start']      = 'Date de début';
$_['entry_date_end']        = 'Date de fin';
?>