<?php
// Heading
$_['heading_title']     = 'Rapport des Produits Achetés';

// Text
$_['text_list']         = 'Liste des Produits Achetés';
$_['text_all_status']   = 'Tous les Statuts';

// Column
$_['column_date_start'] = 'Date de Début';
$_['column_date_end']   = 'Date de Fin';
$_['column_name']       = 'Nom du Produit';
$_['column_model']      = 'Modèle';
$_['column_quantity']   = 'Quantité';
$_['column_total']      = 'Total';

// Entry
$_['entry_date_start']  = 'Date de Début';
$_['entry_date_end']    = 'Date de Fin';
$_['entry_status']      = 'Statut de la Commande';