<?php
// Heading
$_['heading_title']    = 'Rapport sur le Marketing';

// Text
$_['text_list']        = 'Liste du marketing';
$_['text_all_status']  = 'Tous les états';

// Column
$_['column_campaign']  = 'Nom Campagne';
$_['column_code']      = 'Code';
$_['column_clicks']    = 'Clics';
$_['column_orders']    = 'Nb de commandes';
$_['column_total']     = 'Total';

// Entry
$_['entry_date_start'] = 'Date de début';
$_['entry_date_end']   = 'Date de fin';
$_['entry_status']     = 'État de commande';
?>