<?php
// Heading
$_['heading_title']       = 'Filtre';

// Text
$_['text_module']         = 'Modules';
$_['text_success']        = 'Succès: Vous avez modifié le module Filtre !';
$_['text_edit']           = 'Modifier le module Filtre';

// Entry
$_['entry_status']        = 'Statut';

// Error
$_['error_permission']    = 'Attention: Vous n\'avez pas les droits nécessaires pour modifier le module Filtre !';
?>