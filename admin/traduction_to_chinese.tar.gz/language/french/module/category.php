<?php
// Heading
$_['heading_title']       = 'Catégorie';

// Text
$_['text_module']         = 'Modules';
$_['text_success']        = 'Succès: Vous avez modifié le module Catégorie !';
$_['text_edit']           = 'Modifier le module Catégorie';

// Entry
$_['entry_status']        = 'Statut';

// Error
$_['error_permission']    = 'Attention: Vous n\'avez pas les droits nécessaires pour modifier le module Catégorie !';
?>
