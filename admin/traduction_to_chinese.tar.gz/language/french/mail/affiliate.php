<?php
// Text
$_['text_approve_subject']      = '%s - Votre compte d\'affilié a été activé !';
$_['text_approve_welcome']      = 'Bienvenue et merci de vous être enregistré(e) sur %s !';
$_['text_approve_login']        = 'Votre compte vient d\'être créé et vous pouvez maintenant vous connecter à l\'aide de votre adresse e-mail et de votre mot de passe pour visiter notre site web à l\'URL suivante:';
$_['text_approve_services']     = 'Après vous être connecté(e), vous pourrez générer des codes de suivi, suivre les paiements des commissions et modifier vos informations de compte.';
$_['text_approve_thanks']       = 'Merci,';
$_['text_transaction_subject']  = '%s - Commission d\'Affilié';
$_['text_transaction_received'] = 'Vous avez reçu une commission de %s !';
$_['text_transaction_total']    = 'Le montant total de vos commissions est maintenant de %s.';
?>