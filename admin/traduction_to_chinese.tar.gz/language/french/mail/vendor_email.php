<?php
$_['text_vendor_email'] = 'Thinkwinetrade.com Votre Bon de Commande/Purchase Order (PO) ';
$_['text_vendor_email_subject'] = 'Vous Avez une Nouvelle Commande - ';
$_['text_vendor_order_id'] = 'ID Commande: ';
$_['text_title'] = 'Mr/Mme. ';
$_['text_vendor_contact'] = 'Contact Producteur';
$_['text_shipping_address'] = 'Adresse Livraison Entrepot';
$_['text_order_details'] = 'Details de la Commande';
$_['text_date_ordered'] = 'Date de Création:';
$_['text_email'] = 'Email: ';
$_['text_telephone'] = 'Téléphone: ';
$_['text_order_status'] = 'Statut de la Commande: ';
$_['text_payment_method'] = 'Mode de Payment:';
$_['text_vendor_auto_msg'] = 'Ceci est un message généré automatiquement, veuillez ne pas répondre directement! vous pouvez cependant nous contacter a cet adresse mail sales@thinkwinetrade.com en nous indiquant l\'ID Commande en titre du message, Bien Cordialement';
$_['text_txn_subject'] = 'Thinkiwinetrade.com [PAIEMENT] envoyé';
$_['text_dear'] = 'Dear ';
$_['text_txn_body'] = 'You have Received a new payment for  Order #%s  for the amount of  %s :';
$_['text_txn_body1'] = 'We thank you for you for your quick response to this order, all your product are now being processed to be shipped to the final customer.<br/><br/>Please stay around for more orders, if you have any questions please contact us at this address: sales@thinkwinetrade.com
<br/><br/>
<b>Kind Regards,</b>
<br/><br/>
<b>TWT team.</b>';
$_['column_product'] = 'Produit';
$_['column_model'] = 'Modèle';
$_['column_quantity'] = 'Quantité<br>(cartons)';
$_['column_unit_price'] = 'Prix par Carton';
$_['column_total'] = 'Total';
$_['column_shipping'] = 'Weight Based Shipping';
$_['column_subtotal'] = 'Sous-Total HT';
$_['text_vat'] = 'Dont TVA (20%)';
$_['text_vendor_order'] = 'Commande ';
$_['text_new_subject'] = '%s - Order %s';
$_['column_flat_shipping'] = 'Flat Rate Shipping';
?>