<?php
// Heading
$_['heading_title'] = 'Page introuvable !';

// Text
$_['text_not_found'] = 'La page recherchée ne peut être trouvée ! Veuillez contacter votre administrateur système si le problème persiste.';
?>
