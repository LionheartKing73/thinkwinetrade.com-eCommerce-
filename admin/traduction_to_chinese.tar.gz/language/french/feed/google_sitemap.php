<?php
// Heading
$_['heading_title']    = 'Google Sitemap';

// Text
$_['text_feed']        = 'Flux de Produit';
$_['text_success']     = 'Succès: Vous avez modifié le flux Google Sitemap !';
$_['text_edit']        = 'Modifier le flux Google Sitemap';

// Entry
$_['entry_status']     = 'Statut';
$_['entry_data_feed']  = 'URL du flux de données';

// Error
$_['error_permission'] = 'Attention: Vous n\'avez pas les droits nécessaires pour modifier le flux de produit Google Sitemap !';
?>