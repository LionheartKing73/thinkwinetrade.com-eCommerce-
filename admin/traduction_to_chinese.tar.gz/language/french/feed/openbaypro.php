<?php
// Heading
$_['heading_title']  = 'OpenBay Pro';

// Text
$_['text_module']    = 'Modules';
$_['text_installed'] = 'Le module OpenBay Pro est maintenant installé. Il est disponible sous [Extensions -> OpenBay Pro]';
?>