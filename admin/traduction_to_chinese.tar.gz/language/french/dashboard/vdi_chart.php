<?php
// Heading
$_['heading_title'] = 'Analytiques des Ventes';

// Text
$_['text_order']    = 'Commandes';
$_['text_customer'] = 'Clients';
$_['text_day']      = 'Aujourd\'hui';
$_['text_week']     = 'Semaine';
$_['text_month']    = 'Mois';
$_['text_year']     = 'Année';