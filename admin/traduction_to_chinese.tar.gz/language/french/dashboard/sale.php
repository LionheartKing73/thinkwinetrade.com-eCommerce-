<?php
// Heading
$_['heading_title'] = 'Total Ventes';

// Text
$_['text_view']     = 'Plus...';
?>