<?php
// Heading
$_['heading_title']     = 'Dernières Commandes';

// Column
$_['column_order_id']   = 'ID Commande';
$_['column_customer']   = 'Client';
$_['column_status']     = 'Status';
$_['column_total']      = 'Total';
$_['column_date_added'] = 'Date de Création';
$_['column_action']     = 'Action';
$_['column_product']     = 'Produit';
$_['column_quantity']     = 'Quantité';