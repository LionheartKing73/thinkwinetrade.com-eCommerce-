<?php
$_['heading_title'] = 'Total des Ventes';
$_['heading_new_title'] = 'Total Ventes Confirmées';
$_['text_view'] = 'Plus...';
?>