<?php
$_['text_complete_status']   = 'Commandes Terminées';
$_['text_processing_status'] = 'Commandes en Traitement';
$_['text_other_status']      = 'Autres États';
?>