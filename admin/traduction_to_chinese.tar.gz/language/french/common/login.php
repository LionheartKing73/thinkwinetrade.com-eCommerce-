<?php
$_['heading_title'] = 'Connexion';
$_['text_heading'] = 'Connexion à l\'administration';
$_['text_login'] = 'Page de Connexion Partenaires';
$_['text_forgotten'] = 'Mot de passe oublié';
$_['text_login_heading'] = 'Vos Identifiants';
$_['entry_username'] = 'Utilisateur';
$_['entry_password'] = 'Mot de passe';
$_['button_login'] = 'Connexion';
$_['create_account'] = 'Créer votre compte';
$_['donot_has_account'] = 'Vous n\'avez pas de compte?';
$_['error_login'] = 'Mauvaise correspondance entre utilisateur et mot de passe.';
$_['error_token'] = 'Session invalide. Veuillez vous connecter à nouveau.';
?>